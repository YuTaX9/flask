from flask import request, jsonify, redirect, url_for, render_template
from flask_login import login_user, logout_user, login_required, current_user
from models import User, Contact
from config import app, db

@app.route('/register', methods=['POST'])
def register():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    full_name = data.get('fullName')  # Get the full name from the request
    email = data.get('email')  # Get the email from the request

    # Check if the user or email already exists
    if User.query.filter_by(username=username).first() or User.query.filter_by(email=email).first():
        return jsonify({'message': 'User or email already exists'}), 400

    user = User(username=username, full_name=full_name, email=email)  # Create the new user with full name and email
    user.set_password(password)
    db.session.add(user)
    db.session.commit()

    return jsonify({'message': 'User registered successfully!'}), 201


@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    user = User.query.filter_by(username=username).first()
    if user is None or not user.check_password(password):
        return jsonify({'message': 'Invalid username or password'}), 401

    login_user(user)
    return jsonify({'message': 'Logged in successfully!'}), 200

@app.route('/logout', methods=['GET'])
@login_required
def logout():
    logout_user()
    return jsonify({'message': 'Logged out successfully!'}), 200

@app.route('/home', methods=['GET'])
@login_required
def home():
    return jsonify({'message': 'Welcome to the VR Learning Home Page'})

@app.route('/')
def index():
    return "Welcome to the VR Learning App!"

@app.route('/users', methods=['GET'])
def get_users():
    users = User.query.all()  # Query all users
    user_list = [{"id": user.id, "username": user.username, "fullName": user.full_name, "email": user.email} for user in users]
    return jsonify(user_list), 200



if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)

