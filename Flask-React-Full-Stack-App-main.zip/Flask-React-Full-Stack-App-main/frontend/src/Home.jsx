import React from "react";

function Home() {
  return (
    <div className="container mt-5">
      <h1>Welcome to the VR Learning Home Page!</h1>
      <p>Click below to play the game made with Godot!</p>

      {/* Link to your Godot game */}
      <a href="https://yutax9.github.io/godot-web-vr/" target="_blank" rel="noopener noreferrer" className="btn btn-primary">
        Play the Game
      </a>

      {/* Or if it's a downloadable file */}
      {
      <a href="/path/to/game.zip" download className="btn btn-primary">
        Download the Game
      </a>
      }

    </div>
  );
}

export default Home;
