from flask import Flask, render_template, request
import requests

app = Flask(__name__)

api_key = '30d4741c779ba94c470ca1f63045390a'

@app.route('/', methods=['GET', 'POST'])
def index():
    weather = None
    temp = None
    temp_min = None
    temp_max = None
    humidity = None
    wind_speed = None
    pressure = None
    weather_main = None  # Add weather condition
    
    if request.method == 'POST':
        city = request.form['city']
        weather_data = requests.get(
            f"https://api.openweathermap.org/data/2.5/weather?q={city}&units=imperial&APPID={api_key}")
        
        if weather_data.json()['cod'] == '404':
            weather = "No City Found"
            temp = None
            temp_min = None
            temp_max = None
            humidity = None
            wind_speed = None
            pressure = None
            weather_main = None
        else:
            weather = weather_data.json()['weather'][0]['main']
            temp = round(weather_data.json()['main']['temp'])
            temp_min = round(weather_data.json()['main']['temp_min'])
            temp_max = round(weather_data.json()['main']['temp_max'])
            humidity = weather_data.json()['main']['humidity']
            wind_speed = weather_data.json()['wind']['speed']
            pressure = weather_data.json()['main']['pressure']
            weather_main = weather_data.json()['weather'][0]['main']
    
    return render_template('index.html', weather=weather, temp=temp, temp_min=temp_min,
                           temp_max=temp_max, humidity=humidity, wind_speed=wind_speed,
                           pressure=pressure, weather_main=weather_main)

if __name__ == '__main__':
    app.run(debug=True)
