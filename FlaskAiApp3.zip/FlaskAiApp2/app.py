from flask import Flask, render_template, request, flash
import requests

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Needed for flashing messages

# Your Bing API subscription key
subscription_key = "0d1a80b322464a3281082888446e0bb0"
search_url = "https://api.bing.microsoft.com/v7.0/search"

@app.route('/', methods=['GET', 'POST'])
def index():
    results = []
    if request.method == 'POST':
        query = request.form['query']
        headers = {"Ocp-Apim-Subscription-Key": subscription_key}
        params = {"q": query, "textDecorations": True, "textFormat": "HTML"}
        
        try:
            response = requests.get(search_url, headers=headers, params=params)
            response.raise_for_status()
            search_results = response.json()
            results = search_results.get('webPages', {}).get('value', [])
        except requests.exceptions.RequestException as e:
            flash(f"An error occurred: {e}", "error")
    
    return render_template('index.html', results=results)

if __name__ == '__main__':
    app.run(debug=True)
