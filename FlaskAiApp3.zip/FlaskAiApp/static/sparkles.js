document.addEventListener('DOMContentLoaded', function() {
    const sparkles = document.querySelectorAll('.sparkles');

    sparkles.forEach(element => {
        element.addEventListener('mouseover', function() {
            this.style.animation = 'sparkle 1s infinite';
        });

        element.addEventListener('mouseout', function() {
            this.style.animation = 'none';
        });
    });
});
